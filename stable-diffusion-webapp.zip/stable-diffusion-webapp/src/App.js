import React, { useState } from "react";
import "./App.css";
//import fordad from "./output_images/fordad.jpg";
//import bmw from "./output_images/bmw.png"
//import shoe from "./output_images/bleachers.png"
//import creami from "./output_images/creami_2.png"


function App() {
  const [text, setText] = useState("");
  const [image, setImage] = useState(null);
  const [outputImage, setOutputImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [caption, setCaption] = useState(""); // New state for the caption
  const [additionalInput, setAdditionalInput] = useState("");
  const [showThemesDropdown, setShowThemesDropdown] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState(""); // New state for selected theme

  console.log("Hello from the App component!");

  const handleTextChange = (e) => setText(e.target.value);
  const handleImageChange = (e) => setImage(e.target.files[0]);
  const handleAdditionalInputChange = (e) => setAdditionalInput(e.target.value);
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
  
    const formData = new FormData();
    formData.append("text", text); // Text prompt
    if (image) formData.append("image", image); // Uploaded image
  
    try {
      const response = await fetch("http://localhost:5000/generate", {
        method: "POST",
        body: formData,
      });
  
      const result = await response.json();
  
      if (result.success) {
        // Display the generated image
        const generatedImageBase64 = `data:image/png;base64,${result.generated_image}`;
        setOutputImage(generatedImageBase64);
        setCaption("Generated image based on your input!");
      } else {
        alert(result.message || "Failed to generate image. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while processing your request.");
    } finally {
      setLoading(false);
    }
  };
  
  /*
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData();
    formData.append("text", text);
    if (image) formData.append("image", image);
    formData.append("additionalInput", additionalInput);
    /*try {
      const response = await fetch("http://127.0.0.1:5000/api/process", {
        method: "POST",
        body: formData,
      });
    setTimeout(() => {
      try {
        
        // Generate caption based on keywords in the text input
        if (text.includes("bmw")) {
          setOutputImage(bmw);
          setCaption("Wherever You Go, Whatever You Carry—Built to Handle It All");
        } else if (text.includes("shoe")) {
          setOutputImage(shoe);
          setCaption("Where Legends Wait Their Turn");
        } else if (text.includes("cream")) {
          setOutputImage(creami);
          setCaption("Endless Possibilities at the Press of a Button. Smooth, Creamy, and Effortless");
        }
        // Simulate image generation by setting the local image path
        //setOutputImage(fordad); // Update state with the local image path
        console.log("Image has been loaded");
      } catch (error) {
        console.error("Error:", error);
        alert("Failed to generate image. Please try again.");
      } finally {
        setLoading(false);
      }
      console.log("Image has been loaded");

    }, 7000);
  };*/

  const toggleThemesDropdown = () => {
    setShowThemesDropdown(!showThemesDropdown);
  };

  const handleThemeSelect = (theme) => {
    setSelectedTheme(theme); // Update the selected theme
    setShowThemesDropdown(false); // Close the dropdown
  };

  return (
    <div className="app-container">
      <div className="sidebar">
        <h2>Menu</h2>
        <ul>
          <li>Home</li>
          <li>Instructions</li>
          <li>FAQ</li>
          <li>Settings and Privacy</li>
        </ul>
      </div>
      <div className="content">
        <h1>Stable Diffusion Image Generator</h1>
        <form onSubmit={handleSubmit}>
          <label>Text Prompt:</label>
          <textarea
            value={text}
            onChange={handleTextChange}
            placeholder="Enter text prompt here"
          ></textarea>

          <label>Upload Base Image (Optional):</label>
          <input type="file" onChange={handleImageChange} accept="image/*" />

          <label>Input for Caption Generation:</label>
          <input
            type="text"
            value={additionalInput}
            onChange={handleAdditionalInputChange}
            placeholder="Input for caption generation"
          />

          <button type="submit" disabled={loading}>
            {loading ? "Generating..." : "Generate Image"}
          </button>
        </form>

        {outputImage && (
          <div className="output-section">
            <h2>Generated Image:</h2>
            <img src={outputImage} alt="Generated" />
            {caption && <p className="image-caption">{caption}</p>}
          </div>
        )}

      </div>

      {/* Themes Section */}
      <div className="themes-section">
        <button onClick={toggleThemesDropdown} className="themes-button">
          Themes
        </button>
        {showThemesDropdown && (
          <ul className="themes-dropdown">
            <li onClick={() => handleThemeSelect("Semi-realistic")}>Semi-realistic</li>
            <li onClick={() => handleThemeSelect("Artistic")}>Artistic</li>
            <li onClick={() => handleThemeSelect("Atmospheric")}>Atmospheric</li>
            <li onClick={() => handleThemeSelect("Thematic")}>Thematic</li>
            <li onClick={() => handleThemeSelect("Illustrative")}>Illustrative</li>
          </ul>
        )}
        {selectedTheme && (
          <p className="selected-theme">
            Selected Theme: <strong>{selectedTheme}</strong>
          </p>
        )}
      </div>
    </div>
  );
}

export default App;
